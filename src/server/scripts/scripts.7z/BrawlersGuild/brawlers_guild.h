void AddSC_brawlers_guild()
{
   void brawlers_guild();
   void brawlers_guild_bosses_rank_one();
   void brawlers_guild_bosses_rank_two();
   void brawlers_guild_bosses_rank_three();
   void brawlers_guild_bosses_rank_four();
   void brawlers_guild_bosses_rank_five();
   void brawlers_guild_bosses_rank_six();
   void brawlers_guild_bosses_rank_seven();
};

