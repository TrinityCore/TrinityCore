Level: 62 - 65
Battle pet level: 25
Territory: Contested
Instance type: Zone
Zone ID: 13645
Added in patch 10.0.0.44592