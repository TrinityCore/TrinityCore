#include "necrotic_wake.h"

void AddSC_boss_nalthor()
{
}