/*
 * Copyright (C) 2022 BfaCore Reforged
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "ScriptMgr.h"
#include "ScriptedCreature.h"
#include "ScriptMgr.h"
#include "ScriptedCreature.h"
#include "ScriptMgr.h"
#include "SpellMgr.h"
#include "SpellInfo.h"
#include "ScriptedCreature.h"
#include "GameObjectAI.h"
#include "ScriptMgr.h"
#include "ScriptedCreature.h"
#include "ObjectMgr.h"
#include "ScriptMgr.h"
#include "ScriptedCreature.h"
#include "SpellScript.h"
#include "SpellAuraEffects.h"
#include "SpellAuras.h"
#include "MapManager.h"
#include "Spell.h"
#include "Vehicle.h"
#include "Cell.h"
#include "CellImpl.h"
#include "GridNotifiers.h"
#include "GridNotifiersImpl.h"
#include "CreatureTextMgr.h"
#include "MoveSplineInit.h"
#include "Weather.h"
#include "GameObjectAI.h"
#include "ScriptMgr.h"
#include "ScriptedCreature.h"
#include "ObjectMgr.h"
#include "ScriptMgr.h"
#include "ScriptedCreature.h"
#include "SpellScript.h"
#include "SpellAuraEffects.h"
#include "SpellAuras.h"
#include "MapManager.h"
#include "Spell.h"
#include "Vehicle.h"
#include "Cell.h"
#include "CellImpl.h"
#include "GridNotifiers.h"
#include "GridNotifiersImpl.h"
#include "CreatureTextMgr.h"
#include "Weather.h"
#include <Instances/InstanceScript.h>
#include <Movement/MotionMaster.h>
#include "SpellInfo.h"
#include "Player.h"
#include "MotionMaster.h"
#include "ScriptMgr.h"
#include "ScriptedCreature.h"
#include "Vehicle.h"
#include "GameObject.h"
#include <Instances/InstanceScript.h>
#include "TemporarySummon.h"
#include "Position.h"
#include <Globals/ObjectAccessor.h>
#include <Maps/Map.cpp>
#include "MapInstanced.h"
#include <Instances/InstanceScript.h>
#include <DungeonFinding/LFGMgr.h>
#include "LFG.h"
#include "InstanceScript.h"
#include "EventMap.h"
#include <Instances/InstanceScript.h>

enum eBoss
{
    BOSS_WASE_MARI = 1
};

enum eSpells
{
    SPELL_WATER_BUBBLE              = 106062,
    SPELL_CALL_WATER                = 106526,
    SPELL_CORRUPTED_FOUTAIN         = 106518,
    SPELL_SHA_RESIDUE               = 106653,
    SPELL_HYDROLANCE_PRECAST        = 115220,
    SPELL_HYDROLANCE_DMG_BOTTOM     = 106267,
    SPELL_HYDROLANCE_VISUAL         = 106055,
    SPELL_HYDROLANCE_DMG            = 106105,
    SPELL_WASH_AWAY                 = 106331
};

enum eTexts
{
    TEXT_INTRO            = 0,
    TEXT_AGGRO            = 1,
    TEXT_BOSS_EMOTE_AGGRO = 2,
    TEXT_CALL_WATER       = 3,
    TEXT_PHASE_SWITCH     = 4,
    TEXT_DEATH            = 5,
    TEXT_KILL_PLAYER      = 6
};

enum eEvents
{
    EVENT_CALL_WATER        = 1,
    EVENT_HYDROLANCE        = 2,
    EVENT_HYDROLANCE_START  = 3,
    EVENT_SWITCH_PHASE_TWO  = 4,
    EVENT_WASH_AWAY         = 5
};

enum eCreatures
{
    CREATURE_FOUTAIN_TRIGGER            = 56586,
    CREATURE_CORRUPT_DROPLET            = 62358,
    CREATURE_HYDROLANCE_BOTTOM_TRIGGER  = 56542
};

enum eTimers
{
    TIMER_CALL_WATTER           = 29000,
    TIMER_HYDROLANCE_START      = 10000,
    TIMER_HYDROLANCE            =  5500,
    TIMER_SWITCH_PHASE_TWO      = 15000,
    TIMER_WASH_AWAY             =   300
};

enum hydrolancePhase
{
    HYDROLANCE_BOTTOM   = 1,
    HYDROLANCE_LEFT     = 2,
    HYDROLANCE_RIGHT    = 3
};

//static const float fountainTriggerPos[4][3] =
//{
//    {1022.743f, -2544.295f, 173.7757f},
//    {1023.314f, -2569.695f, 176.0339f},
//    {1059.943f, -2581.648f, 176.1427f},
//    {1075.231f, -2561.335f, 173.8758f}
//};

static const float hydrolanceLeftTrigger[5][3] =
{
    {1061.411f, -2570.721f, 174.2403f},
    {1058.921f, -2573.487f, 174.2403f},
    {1055.910f, -2575.674f, 174.2403f},
    {1052.511f, -2577.188f, 174.2403f},
    {1048.871f, -2577.961f, 174.2403f}
};

static const float hydrolanceRightTrigger[5][3] =
{
    {1035.333f, -2573.693f, 174.2403f},
    {1032.795f, -2570.971f, 174.2403f},
    {1030.878f, -2567.781f, 174.2403f},
    {1029.667f, -2564.263f, 174.2403f},
    {1029.213f, -2560.569f, 174.2403f}
};

class boss_wase_mari : public CreatureScript
{
    public:
        boss_wase_mari() : CreatureScript("boss_wase_mari") { }

        struct boss_wise_mari_AI : public BossAI
        {
            boss_wise_mari_AI(Creature* creature) : BossAI(creature, BOSS_WASE_MARI)
            {
                creature->AddUnitState(UNIT_STATE_ROOT | UNIT_STATE_CANNOT_TURN);
            }

            bool ennemyInArea;
            bool intro;
            uint8 phase;
            uint8 foutainCount;
            ObjectGuid foutainTrigger[4];
            uint32 hydrolancePhase;

            void Reset() override
            {
                for (uint8 i = 0; i < 4; i++)
                    foutainTrigger[i] = ObjectGuid::Empty;

                std::list<Creature*> searcher;
                me->GetCreatureListWithEntryInGrid(searcher, CREATURE_FOUTAIN_TRIGGER, 50.0f);
                for (auto itr : searcher)
                {
                    if (!itr)
                        continue;

                    itr->RemoveAllAuras();
                }

                hydrolancePhase = 0;
                foutainCount = 0;
                phase = 0;
                ennemyInArea= false;
                intro = false;
                me->RemoveAurasDueToSpell(SPELL_WATER_BUBBLE);

                _Reset();
            }

            void EnterCombat(Unit* /*who*/) override
            {
                std::list<Creature*> searcher;
                GetCreatureListWithEntryInGrid(searcher, me, CREATURE_FOUTAIN_TRIGGER, 50.0f);
                uint8 tab = 0;
                for (auto itr : searcher)
                {
                    if (!itr)
                        continue;

                    itr->RemoveAllAuras();

                    foutainTrigger[++tab] = itr->GetGUID();
                }

                searcher.clear();
                GetCreatureListWithEntryInGrid(searcher, me, CREATURE_CORRUPT_DROPLET, 50.0f);
                for (auto itr : searcher)
                {
                    if (!itr)
                        continue;

                    if (itr->IsSummon())
                        itr->ForcedDespawn();
                }

                me->SetInCombatWithZone();
                me->CastSpell(me, SPELL_WATER_BUBBLE, true);
                Talk(TEXT_AGGRO);
                Talk(TEXT_BOSS_EMOTE_AGGRO);
                intro = true;
                phase = 1;
                hydrolancePhase = HYDROLANCE_BOTTOM;
                events.ScheduleEvent(EVENT_CALL_WATER, 8000);
                events.ScheduleEvent(EVENT_HYDROLANCE_START, TIMER_HYDROLANCE_START);

                _EnterCombat();
            }

            void DoAction(const int32 /*action*/) override
            {}

            void KilledUnit(Unit* /*victim*/) override
            {
                Talk(TEXT_KILL_PLAYER);
            }

            void JustDied(Unit* /*killer*/) override
            {
                Talk(TEXT_DEATH);
                _JustDied();
            }

            void DamageTaken(Unit* /*attacker*/, uint32& /*damage*/) override
            {}

            void MoveInLineOfSight(Unit* who) override
            {
                if (who->GetTypeId() != TYPEID_PLAYER)
                    return;

                if (intro)
                    return;

                if (!ennemyInArea)
                {
                    Talk(TEXT_INTRO);
                    ennemyInArea = true;
                    return;
                }
            }

            void UpdateAI(uint32 diff) override
            {
                if (!UpdateVictim())
                    return;

                events.Update(diff);

                // Wise Mari don't rotate
                if (!me->GetTarget().IsEmpty())
                    me->SetTarget(ObjectGuid::Empty);

                if (me->HasUnitState(UNIT_STATE_CASTING) && phase != 2)
                    return;

                while (uint32 eventId = events.ExecuteEvent())
                {
                    switch (eventId)
                    {
                        case EVENT_CALL_WATER:
                        {
                            if (phase != 1)
                                break;

                            Talk(TEXT_CALL_WATER);

                            Creature* trigger = ObjectAccessor::GetCreature(*me, foutainTrigger[++foutainCount]);
                            if (trigger)
                            {
                                me->CastSpell(trigger, SPELL_CALL_WATER, true);
                                trigger->AddAura(SPELL_CORRUPTED_FOUTAIN, trigger);
                            }

                            if (foutainCount == 4)
                            {
                                phase = 2;
                                events.ScheduleEvent(EVENT_SWITCH_PHASE_TWO, TIMER_SWITCH_PHASE_TWO);
                                break;
                            }
                            events.ScheduleEvent(EVENT_CALL_WATER, TIMER_CALL_WATTER + rand() % 6000);
                            break;
                        }

                        case EVENT_HYDROLANCE_START:
                        {
                            if (phase != 1)
                                break;

                            float facing = 0.00f;
                            events.ScheduleEvent(EVENT_HYDROLANCE, TIMER_HYDROLANCE);
                            switch (hydrolancePhase)
                            {
                                case HYDROLANCE_BOTTOM:
                                    {
                                        std::list<Creature*> trigger;
                                        me->GetCreatureListWithEntryInGrid(trigger,CREATURE_HYDROLANCE_BOTTOM_TRIGGER, 50.0f);
                                        for (auto itr : trigger)
                                            itr->CastSpell(itr, SPELL_HYDROLANCE_PRECAST, true);
                                        facing = 1.23f;
                                        break;
                                    }
                                case HYDROLANCE_RIGHT:
                                    for (int i = 0; i < 5; i++)
                                        me->CastSpell(hydrolanceRightTrigger[i][0], hydrolanceRightTrigger[i][1], hydrolanceRightTrigger[i][2], SPELL_HYDROLANCE_PRECAST, true);
                                    facing = 3.55f;
                                    break;
                                case HYDROLANCE_LEFT:
                                    for (int i = 0; i < 5; i++)
                                        me->CastSpell(hydrolanceLeftTrigger[i][0], hydrolanceLeftTrigger[i][1], hydrolanceLeftTrigger[i][2], SPELL_HYDROLANCE_PRECAST, true);
                                    facing = 5.25f;
                                    break;
                            }
                            me->CastSpell(me, SPELL_HYDROLANCE_VISUAL, false);
                            me->UpdatePosition(me->GetPositionX(), me->GetPositionY(), me->GetPositionZ(), facing);
                            me->SetFacingTo(facing);
                            break;
                        }

                        case EVENT_HYDROLANCE:
                        {
                            if (phase != 1)
                                break;
                            switch (hydrolancePhase)
                            {
                                case HYDROLANCE_BOTTOM:
                                {
                                    std::list<Creature*> trigger;
                                    me->GetCreatureListWithEntryInGrid(trigger,CREATURE_HYDROLANCE_BOTTOM_TRIGGER, 50.0f);
                                    for (auto itr : trigger)
                                        itr->CastSpell(itr->GetPositionX(), itr->GetPositionY(), itr->GetPositionZ(), SPELL_HYDROLANCE_DMG_BOTTOM, true);
                                    break;
                                }
                                case HYDROLANCE_RIGHT:
                                    for (int i = 0; i < 5; i++)
                                        me->CastSpell(hydrolanceRightTrigger[i][0], hydrolanceRightTrigger[i][1], hydrolanceRightTrigger[i][2], SPELL_HYDROLANCE_DMG, true);
                                    break;
                                case HYDROLANCE_LEFT:
                                    for (int i = 0; i < 5; i++)
                                        me->CastSpell(hydrolanceLeftTrigger[i][0], hydrolanceLeftTrigger[i][1], hydrolanceLeftTrigger[i][2], SPELL_HYDROLANCE_DMG, true);
                                    break;
                            }

                            if (hydrolancePhase == HYDROLANCE_RIGHT)
                                hydrolancePhase = HYDROLANCE_BOTTOM;
                            else
                                hydrolancePhase++;

                            events.ScheduleEvent(EVENT_HYDROLANCE_START, TIMER_HYDROLANCE_START);
                            break;

                        }

                        case EVENT_SWITCH_PHASE_TWO:
                        {
                            if (phase !=2)
                                break;

                            Talk(TEXT_PHASE_SWITCH);
                            me->getThreatManager().clearReferences();
                            me->GetMotionMaster()->MovePoint(1, me->GetHomePosition());

                            me->RemoveAurasDueToSpell(SPELL_WATER_BUBBLE);
                            float facing = me->GetOrientation();
                            facing += (float)M_PI/48;

                            if (facing > (float)M_PI*2)
                                facing -= (float)M_PI*2;

                            //me->UpdatePosition(me->GetPositionX(), me->GetPositionY(), me->GetPositionZ(), facing);
                            me->SetOrientation(facing);
                            me->SetFacingTo(facing);
                            me->CastSpell(me, SPELL_WASH_AWAY, true);
                            events.ScheduleEvent(EVENT_WASH_AWAY, TIMER_WASH_AWAY);
                            break;
                        }

                        case EVENT_WASH_AWAY:
                        {
                            if (phase !=2)
                                break;

                            float facing = me->GetOrientation();
                            facing += float(M_PI)/48;

                            if (facing > float(M_PI) *2)
                                facing -= float(M_PI) *2;

                            me->SetOrientation(facing);
                            me->SetFacingTo(facing);

                            events.ScheduleEvent(EVENT_WASH_AWAY, TIMER_WASH_AWAY);
                            break;
                        }
                    }
                }

            }
        };

        CreatureAI* GetAI(Creature* creature) const override
        {
            return new boss_wise_mari_AI(creature);
        }
};

class mob_corrupt_living_water : public CreatureScript
{
    public:
        mob_corrupt_living_water() : CreatureScript("mob_corrupt_living_water") { }

        struct mob_corrupt_living_water_AI : public ScriptedAI
        {
            mob_corrupt_living_water_AI(Creature* creature) : ScriptedAI(creature) {}

            void Reset() override {}

            void JustDied(Unit* /*killer*/) override
            {
                for (int i = 0; i < 4; i++)
                {
                    Position pos = me->GetRandomNearPosition(4.0f);
                    Creature* droplet = me->SummonCreature(CREATURE_CORRUPT_DROPLET, pos);
                    if (!droplet)
                        continue;

                    if (Unit* unit = SelectTarget(SELECT_TARGET_RANDOM))
                        droplet->Attack(unit, true);
                }

                me->CastSpell(me, SPELL_SHA_RESIDUE, true);
            }

            void UpdateAI(uint32 /*diff*/) override
            {
                if (!UpdateVictim())
                    return;

                DoMeleeAttackIfReady();
            }
        };

        CreatureAI* GetAI(Creature* creature) const override
        {
            return new mob_corrupt_living_water_AI(creature);
        }
};

void AddSC_boss_wise_mari()
{
    new boss_wase_mari();
    new mob_corrupt_living_water();
}
