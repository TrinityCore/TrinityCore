/*
SQLyog Job Agent v12.08 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.43-log : Database - world
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`world` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `world`;

/*Table structure for table `instance_spawn_groups` */

DROP TABLE IF EXISTS `instance_spawn_groups`;

CREATE TABLE `instance_spawn_groups` (
  `instanceMapId` smallint(5) unsigned NOT NULL,
  `bossStateId` tinyint(3) unsigned NOT NULL,
  `bossStates` tinyint(3) unsigned NOT NULL,
  `spawnGroupId` int(10) unsigned NOT NULL,
  `flags` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`instanceMapId`,`bossStateId`,`spawnGroupId`,`bossStates`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `instance_spawn_groups` */

insert  into `instance_spawn_groups` values (249,0,23,10,1),(565,0,23,11,1),(565,1,23,12,1),(544,0,23,13,1),(616,0,23,14,1),(615,1,23,15,1),(615,2,23,16,1),(615,3,23,17,1),(615,0,23,18,1),(724,0,23,19,1),(724,2,23,20,1),(724,1,23,21,1),(724,3,23,22,1),(576,0,23,23,1),(576,1,23,24,1),(576,2,23,25,1),(576,3,23,26,1),(576,4,23,27,1),(624,0,23,28,1),(624,1,23,29,1),(624,2,23,30,1),(624,3,23,31,1),(604,0,23,32,1),(604,1,23,33,1),(604,2,23,34,1),(604,3,23,35,1),(604,4,23,36,1),(658,0,23,39,1),(658,1,23,40,1),(658,2,23,41,1),(658,0,23,42,1),(658,1,23,42,1),(658,0,23,43,1),(658,1,23,43,1),(632,0,23,37,1),(632,1,23,38,1),(550,1,23,44,1),(550,3,23,45,1),(550,2,23,46,1),(550,0,23,47,1),(543,0,23,48,1),(543,1,23,49,1),(543,2,8,49,2),(543,3,8,49,2),(543,1,23,50,1),(543,2,23,51,1),(543,3,8,51,2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
