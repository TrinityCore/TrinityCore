/*
SQLyog Job Agent v12.08 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.43-log : Database - world
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`world` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `world`;

/*Table structure for table `creature_template_outfits` */

DROP TABLE IF EXISTS `creature_template_outfits`;

CREATE TABLE `creature_template_outfits` (
  `entry` int(10) unsigned NOT NULL,
  `npcsoundsid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'entry from NPCSounds.dbc/db2',
  `race` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `gender` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0 for male, 1 for female',
  `skin` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `face` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `hair` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `haircolor` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `facialhair` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `head` int(10) NOT NULL DEFAULT '0',
  `shoulders` int(10) NOT NULL DEFAULT '0',
  `body` int(10) NOT NULL DEFAULT '0',
  `chest` int(10) NOT NULL DEFAULT '0',
  `waist` int(10) NOT NULL DEFAULT '0',
  `legs` int(10) NOT NULL DEFAULT '0',
  `feet` int(10) NOT NULL DEFAULT '0',
  `wrists` int(10) NOT NULL DEFAULT '0',
  `hands` int(10) NOT NULL DEFAULT '0',
  `back` int(10) NOT NULL DEFAULT '0',
  `tabard` int(10) NOT NULL DEFAULT '0',
  `guildid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text,
  PRIMARY KEY (`entry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Use positive values for item entries and negative to use item displayid for head, shoulders etc.';

/*Data for the table `creature_template_outfits` */

insert  into `creature_template_outfits` values (2147483648,0,7,8,1,4,3,8,8,0,0,0,0,2292,16437,0,-5744,0,0,0,0,0,'Kinndy'),(2147483649,0,1,8,1,2,3,22,0,0,0,-10474,-55221,-55222,-9684,-10436,-5744,0,0,-16533,-54176,0,'Amara'),(2147483650,0,7,8,0,2,5,12,1,5,0,-10474,-55221,-55222,-9684,-10436,-5744,0,0,-16533,-54176,0,'Tari'),(2147483651,0,1,8,0,2,7,7,4,6,0,-10474,-55221,-55222,-9684,-10436,-5744,0,0,-16533,-54176,0,'Thoder'),(2147483652,0,10,8,0,0,3,4,9,8,0,-10474,-55221,-55222,-9684,-10436,-5744,0,0,-16533,-54176,0,'Thalen'),(2147483653,0,1,8,0,0,5,5,5,3,0,-52736,-10705,-53258,-53259,-53260,-53261,-24767,-53262,0,-54176,0,'Rhonin'),(2147483654,0,1,8,1,1,1,14,5,0,0,2913,0,13858,0,0,6836,0,0,0,0,0,'Helaina'),(2147483655,0,6,1,0,6,2,2,0,4,1280,0,0,20575,0,20524,0,0,3152,0,0,0,''),(2147483656,0,6,1,0,6,2,2,0,4,0,0,0,20575,0,20524,0,0,3152,0,0,0,''),(2147483657,0,2,1,0,2,7,2,5,1,6686,20158,0,0,0,15431,15426,0,15429,0,15197,0,''),(2147483658,0,2,1,1,2,7,2,5,1,6686,20158,0,0,0,15431,15426,0,15429,0,15197,0,''),(2147483659,0,2,1,0,2,0,0,0,0,28583,7532,0,7439,0,7440,7444,0,7443,0,15197,0,''),(2147483660,0,5,8,1,1,6,11,3,2,28586,7473,0,10001,0,0,32787,0,0,0,0,0,''),(2147483661,0,2,8,1,2,6,0,0,0,17570,17573,0,17572,0,0,17576,0,17577,0,0,0,''),(2147483662,0,2,8,0,2,6,0,0,0,17570,17573,0,17572,0,0,17576,0,17577,0,0,0,''),(2147483663,0,8,8,1,1,0,1,1,5,13113,0,0,14091,0,0,0,24853,0,0,0,0,''),(2147483664,0,1,8,1,2,3,12,4,0,0,2913,0,13858,0,0,6836,0,0,0,-7690,0,''),(2147483665,0,1,8,0,2,3,12,4,0,0,2913,0,13858,0,0,6836,0,0,0,-7690,0,'');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
