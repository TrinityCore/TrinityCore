/*
SQLyog Job Agent v12.08 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.6.43-log : Database - world
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`world` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `world`;

/*Table structure for table `spell_group_stack_rules` */

DROP TABLE IF EXISTS `spell_group_stack_rules`;

CREATE TABLE `spell_group_stack_rules` (
  `group_id` int(11) unsigned NOT NULL DEFAULT '0',
  `stack_rule` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `spell_group_stack_rules` */

insert  into `spell_group_stack_rules` values (1,1),(2,1),(1001,1),(1002,4),(1003,4),(1004,4),(1005,4),(1006,1),(1007,1),(1008,1),(1009,1),(1010,2),(1011,2),(1015,3),(1016,4),(1019,3),(1022,4),(1025,3),(1029,1),(1033,1),(1036,4),(1037,3),(1038,3),(1046,4),(1048,4),(1051,3),(1054,3),(1055,4),(1056,3),(1058,3),(1059,3),(1060,3),(1061,4),(1062,4),(1083,4),(1084,4),(1085,4),(1086,4),(1087,4),(1088,4),(1089,4),(1090,4),(1093,4),(1094,3),(1095,4),(1096,4),(1097,1),(1098,4),(1099,2),(1100,1),(1101,3),(1104,1),(1105,3),(1106,1),(1107,4),(1108,4),(1109,1),(1110,1),(1121,1),(1111,1),(1023,4),(1024,4);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
